PRACHAAR ANDROID PROJECT

Ye native Android project hai. App internet/local server par depend nahi karta.
HTML app ko APK ke andar assets me load kiya gaya hai.

APK banane ka sabse aasaan tareeka:
1. Is ZIP ko GitHub repository me upload karo.
2. GitHub me Actions tab kholo.
3. "Build Prachaar APK" workflow select karo.
4. "Run workflow" dabao.
5. Build complete hone par Artifacts me "Prachaar-debug-apk" download karo.
6. ZIP ke andar app-debug.apk milega.

IMPORTANT:
- 127.0.0.1:3001 use nahi hota.
- App offline local HTML se chalega.
- Ye demo marketplace UI hai; real login/database/chat/payment backend abhi connected nahi hai.
